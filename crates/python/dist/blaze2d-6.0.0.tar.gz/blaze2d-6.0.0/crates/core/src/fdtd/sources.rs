//! Time-domain sources for FDTD simulations.
//!
//! This module implements sources matching Meep's conventions for exciting
//! electromagnetic fields in FDTD simulations.
//!
//! # Source Types
//!
//! - **Gaussian**: Smooth pulse with specified center frequency and bandwidth
//! - **ContinuousWave**: Monochromatic source (Gaussian turn-on)
//!
//! # Source Geometry
//!
//! Sources can be:
//! - **Point**: Single grid cell
//! - **Line**: 1D line of cells (for plane waves)
//! - **Area**: 2D region of cells
//!
//! # Meep Compatibility
//!
//! Meep's Gaussian source is defined as:
//!   J(t) = A * exp(-(t - t₀)² / (2σ²)) * exp(-iω₀(t - t₀))
//!
//! In real form (for FDTD):
//!   J(t) = A * exp(-(t - t₀)² / (2σ²)) * cos(ω₀(t - t₀) + φ)
//!
//! where σ = 1/(2πΔf) relates to the bandwidth Δf.

use serde::{Deserialize, Serialize};

use super::fields::FieldComponent;

/// Source amplitude profile in time.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum SourceType {
    /// Gaussian pulse with specified center frequency and width.
    Gaussian(GaussianSource),
    /// Continuous wave with Gaussian turn-on.
    ContinuousWave(ContinuousWaveSource),
    /// Custom time function (evaluated at each time step).
    Custom,
}

/// Gaussian pulse source (Meep-compatible).
///
/// The time profile is:
///   f(t) = exp(-(t - t₀)² / (2σ²)) * cos(ω(t - t₀) + φ)
///
/// where:
/// - t₀ = peak_time (when the envelope peaks)
/// - σ = width (standard deviation of envelope)
/// - ω = 2π * frequency (angular frequency)
/// - φ = phase
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GaussianSource {
    /// Center frequency in normalized units (c/a where a is lattice constant)
    pub frequency: f64,
    /// Gaussian width (σ) - standard deviation of the envelope
    /// Relates to bandwidth: Δf ≈ 1/(2πσ)
    pub width: f64,
    /// Peak time (t₀) - when the Gaussian envelope reaches maximum
    pub peak_time: f64,
    /// Phase offset in radians
    #[serde(default)]
    pub phase: f64,
    /// Amplitude
    #[serde(default = "default_amplitude")]
    pub amplitude: f64,
    /// Cutoff factor for source (source is zero when envelope < cutoff * max)
    #[serde(default = "default_cutoff")]
    pub cutoff: f64,
}

fn default_amplitude() -> f64 {
    1.0
}

fn default_cutoff() -> f64 {
    1e-5
}

impl GaussianSource {
    /// Create a new Gaussian source.
    ///
    /// # Arguments
    /// - `frequency`: Center frequency (c/a units)
    /// - `width`: Gaussian width σ (time units)
    /// - `peak_time`: When the pulse peaks
    pub fn new(frequency: f64, width: f64, peak_time: f64) -> Self {
        Self {
            frequency,
            width,
            peak_time,
            phase: 0.0,
            amplitude: 1.0,
            cutoff: 1e-5,
        }
    }

    /// Create from frequency and fractional bandwidth.
    ///
    /// # Arguments
    /// - `frequency`: Center frequency
    /// - `fwidth`: Fractional bandwidth Δf/f₀ (FWHM in frequency domain)
    pub fn from_bandwidth(frequency: f64, fwidth: f64) -> Self {
        // FWHM in frequency relates to σ in time by: Δf = sqrt(2*ln(2)) / (π*σ)
        // For simplicity, we use: σ ≈ 1 / (2π * Δf) = 1 / (2π * fwidth * f0)
        let df = fwidth * frequency;
        let width = 1.0 / (2.0 * std::f64::consts::PI * df);
        // Peak time: ensure the pulse starts near zero (5σ before peak)
        let peak_time = 5.0 * width;

        Self::new(frequency, width, peak_time)
    }

    /// Set the phase.
    pub fn with_phase(mut self, phase: f64) -> Self {
        self.phase = phase;
        self
    }

    /// Set the amplitude.
    pub fn with_amplitude(mut self, amplitude: f64) -> Self {
        self.amplitude = amplitude;
        self
    }

    /// Set the peak time.
    pub fn with_peak_time(mut self, peak_time: f64) -> Self {
        self.peak_time = peak_time;
        self
    }

    /// Compute the source value at time t.
    pub fn value_at(&self, t: f64) -> f64 {
        let dt = t - self.peak_time;
        let envelope = (-dt * dt / (2.0 * self.width * self.width)).exp();

        // Apply cutoff
        if envelope < self.cutoff {
            return 0.0;
        }

        let omega = 2.0 * std::f64::consts::PI * self.frequency;
        let oscillation = (omega * dt + self.phase).cos();

        self.amplitude * envelope * oscillation
    }

    /// Compute the derivative of the source at time t.
    /// Useful for current sources that inject dJ/dt.
    pub fn derivative_at(&self, t: f64) -> f64 {
        let dt = t - self.peak_time;
        let sigma2 = self.width * self.width;
        let envelope = (-dt * dt / (2.0 * sigma2)).exp();

        if envelope < self.cutoff {
            return 0.0;
        }

        let omega = 2.0 * std::f64::consts::PI * self.frequency;
        let cos_term = (omega * dt + self.phase).cos();
        let sin_term = (omega * dt + self.phase).sin();

        // d/dt [A * exp(-dt²/2σ²) * cos(ωdt + φ)]
        // = A * exp(...) * [-dt/σ² * cos(...) - ω * sin(...)]
        self.amplitude * envelope * (-dt / sigma2 * cos_term - omega * sin_term)
    }

    /// Check if the source is effectively over (envelope below cutoff).
    pub fn is_finished(&self, t: f64) -> bool {
        let dt = t - self.peak_time;
        let envelope = (-dt * dt / (2.0 * self.width * self.width)).exp();
        envelope < self.cutoff && t > self.peak_time
    }

    /// Suggested end time for the source (when envelope is negligible).
    pub fn end_time(&self) -> f64 {
        // 5σ after peak
        self.peak_time + 5.0 * self.width
    }

    /// Suggested start time (when to begin injecting).
    pub fn start_time(&self) -> f64 {
        // Source is effectively zero before this
        (self.peak_time - 5.0 * self.width).max(0.0)
    }
}

/// Continuous wave source with smooth turn-on.
///
/// The time profile is:
///   f(t) = tanh((t - t₀) / rise_time) * cos(ωt + φ)
///
/// This creates a monochromatic source that smoothly turns on.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ContinuousWaveSource {
    /// Frequency in normalized units
    pub frequency: f64,
    /// Rise time for smooth turn-on
    pub rise_time: f64,
    /// Start time for turn-on
    pub start_time: f64,
    /// Phase offset in radians
    #[serde(default)]
    pub phase: f64,
    /// Amplitude
    #[serde(default = "default_amplitude")]
    pub amplitude: f64,
}

impl ContinuousWaveSource {
    /// Create a new CW source.
    pub fn new(frequency: f64, rise_time: f64) -> Self {
        Self {
            frequency,
            rise_time,
            start_time: 0.0,
            phase: 0.0,
            amplitude: 1.0,
        }
    }

    /// Compute the source value at time t.
    pub fn value_at(&self, t: f64) -> f64 {
        if t < self.start_time {
            return 0.0;
        }

        let omega = 2.0 * std::f64::consts::PI * self.frequency;
        let envelope = ((t - self.start_time) / self.rise_time).tanh();
        self.amplitude * envelope * (omega * t + self.phase).cos()
    }
}

/// Geometry of the source region.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum SourceGeometry {
    /// Point source at a single position.
    Point {
        /// Position in Cartesian coordinates
        position: [f64; 2],
    },
    /// Line source (for launching plane waves).
    Line {
        /// Start position
        start: [f64; 2],
        /// End position
        end: [f64; 2],
    },
    /// Rectangular area source.
    Area {
        /// Center position
        center: [f64; 2],
        /// Size [width, height]
        size: [f64; 2],
    },
}

impl SourceGeometry {
    /// Create a point source at the given position.
    pub fn point(x: f64, y: f64) -> Self {
        Self::Point { position: [x, y] }
    }

    /// Create a point source at the center of the domain.
    pub fn center(lx: f64, ly: f64) -> Self {
        Self::point(lx / 2.0, ly / 2.0)
    }

    /// Create a horizontal line source.
    pub fn horizontal_line(y: f64, x_start: f64, x_end: f64) -> Self {
        Self::Line {
            start: [x_start, y],
            end: [x_end, y],
        }
    }

    /// Create a vertical line source.
    pub fn vertical_line(x: f64, y_start: f64, y_end: f64) -> Self {
        Self::Line {
            start: [x, y_start],
            end: [x, y_end],
        }
    }
}

/// Which field component the source injects into.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum SourceComponent {
    /// Electric field component (Ez for TM, Ex/Ey for TE)
    Electric(FieldComponent),
    /// Magnetic field component (Hx/Hy for TM, Hz for TE)
    Magnetic(FieldComponent),
    /// Current density J (adds to dE/dt equation)
    Current(FieldComponent),
}

impl Default for SourceComponent {
    fn default() -> Self {
        // Default to Hz for TE mode (most common)
        Self::Magnetic(FieldComponent::Hz)
    }
}

/// Complete source specification for FDTD.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Source {
    /// Time profile of the source
    pub source_type: SourceType,
    /// Spatial geometry
    pub geometry: SourceGeometry,
    /// Which field component to inject
    pub component: SourceComponent,
}

impl Source {
    /// Create a new source.
    pub fn new(source_type: SourceType, geometry: SourceGeometry, component: SourceComponent) -> Self {
        Self {
            source_type,
            geometry,
            component,
        }
    }

    /// Create a point Gaussian source for the primary field.
    ///
    /// For TE mode, this injects into Hz.
    /// For TM mode, this injects into Ez.
    pub fn gaussian_point(
        frequency: f64,
        fwidth: f64,
        position: [f64; 2],
        component: FieldComponent,
    ) -> Self {
        let gaussian = GaussianSource::from_bandwidth(frequency, fwidth);
        Self {
            source_type: SourceType::Gaussian(gaussian),
            geometry: SourceGeometry::point(position[0], position[1]),
            component: SourceComponent::Electric(component),
        }
    }

    /// Compute the source value at time t.
    pub fn value_at(&self, t: f64) -> f64 {
        match &self.source_type {
            SourceType::Gaussian(g) => g.value_at(t),
            SourceType::ContinuousWave(cw) => cw.value_at(t),
            SourceType::Custom => 0.0, // Would need callback
        }
    }

    /// Check if the source is effectively finished.
    pub fn is_finished(&self, t: f64) -> bool {
        match &self.source_type {
            SourceType::Gaussian(g) => g.is_finished(t),
            SourceType::ContinuousWave(_) => false, // CW never finishes
            SourceType::Custom => false,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::f64::consts::PI;

    #[test]
    fn test_gaussian_source_creation() {
        let src = GaussianSource::new(0.5, 1.0, 5.0);
        assert_eq!(src.frequency, 0.5);
        assert_eq!(src.width, 1.0);
        assert_eq!(src.peak_time, 5.0);
    }

    #[test]
    fn test_gaussian_source_peak() {
        let src = GaussianSource::new(0.5, 1.0, 5.0).with_phase(0.0);

        // At peak time with phase=0, cos(0) = 1, so value = amplitude * 1 * 1
        let peak_value = src.value_at(5.0);
        assert!((peak_value - 1.0).abs() < 1e-10);
    }

    #[test]
    fn test_gaussian_source_symmetry() {
        let src = GaussianSource::new(0.0, 1.0, 5.0); // Zero frequency = pure Gaussian

        let v1 = src.value_at(4.0);
        let v2 = src.value_at(6.0);
        // Should be symmetric around peak
        assert!((v1 - v2).abs() < 1e-10);
    }

    #[test]
    fn test_gaussian_source_decay() {
        let src = GaussianSource::new(0.0, 1.0, 5.0);

        // At 3σ away, envelope = exp(-4.5) ≈ 0.011
        let v_3sigma = src.value_at(2.0);
        assert!(v_3sigma.abs() < 0.02);

        // At 5σ away, should be essentially zero
        let v_5sigma = src.value_at(0.0);
        assert!(v_5sigma.abs() < src.cutoff);
    }

    #[test]
    fn test_gaussian_from_bandwidth() {
        let f0 = 0.5;
        let fwidth = 0.2; // 20% bandwidth
        let src = GaussianSource::from_bandwidth(f0, fwidth);

        assert_eq!(src.frequency, f0);
        // Width should be approximately 1/(2π * Δf)
        let expected_width = 1.0 / (2.0 * PI * fwidth * f0);
        assert!((src.width - expected_width).abs() < 1e-10);
    }

    #[test]
    fn test_cw_source() {
        let src = ContinuousWaveSource::new(1.0, 1.0);

        // Should be zero before start
        assert_eq!(src.value_at(-1.0), 0.0);

        // Should approach amplitude * cos(ωt) for large t
        let t = 100.0;
        let expected = (2.0 * PI * t).cos();
        let actual = src.value_at(t);
        assert!((actual - expected).abs() < 0.01);
    }

    #[test]
    fn test_source_geometry() {
        let point = SourceGeometry::point(0.5, 0.5);
        match point {
            SourceGeometry::Point { position } => {
                assert_eq!(position, [0.5, 0.5]);
            }
            _ => panic!("Expected point source"),
        }

        let line = SourceGeometry::horizontal_line(0.5, 0.0, 1.0);
        match line {
            SourceGeometry::Line { start, end } => {
                assert_eq!(start[1], 0.5);
                assert_eq!(end[1], 0.5);
            }
            _ => panic!("Expected line source"),
        }
    }
}
