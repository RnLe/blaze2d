//! 2D Finite-Difference Time-Domain (FDTD) solver.
//!
//! This module implements a Meep-compatible FDTD solver for electromagnetic
//! simulations in 2D photonic structures. It reuses Blaze2D's geometry and
//! dielectric smoothing infrastructure while providing:
//!
//! - **Yee lattice**: Staggered grid for E and H field components
//! - **PML boundaries**: Perfectly Matched Layers for absorbing boundaries
//! - **Periodic boundaries**: Bloch-periodic boundaries for infinite structures
//! - **Gaussian sources**: Time-domain excitation matching Meep's conventions
//! - **Field snapshots**: Output for visualization and analysis
//!
//! # Polarization Modes
//!
//! In 2D, Maxwell's equations decouple into two independent polarizations:
//!
//! - **TE (Transverse Electric)**: Hz, Ex, Ey - Electric field in-plane
//! - **TM (Transverse Magnetic)**: Ez, Hx, Hy - Magnetic field in-plane
//!
//! TE mode is the default as it's more commonly used for photonic crystal
//! simulations with air holes in dielectric.
//!
//! # Example
//!
//! ```ignore
//! use blaze2d_core::fdtd::{FdtdSimulation, FdtdConfig, GaussianSource};
//! use blaze2d_core::geometry::Geometry2D;
//!
//! // Create geometry (reuse existing Blaze2D geometry)
//! let geometry = Geometry2D::single_air_hole(lattice, 0.3, 12.0);
//!
//! // Configure FDTD simulation
//! let config = FdtdConfig::default()
//!     .with_resolution(32)
//!     .with_pml_thickness(1.0)
//!     .with_courant(0.5);
//!
//! // Create and run simulation
//! let mut sim = FdtdSimulation::new(geometry, config);
//! sim.add_source(GaussianSource::new(...));
//!
//! for step in 0..1000 {
//!     sim.step();
//!     if step % 100 == 0 {
//!         sim.snapshot(&format!("field_{:04}.csv", step));
//!     }
//! }
//! ```

mod boundaries;
mod config;
mod fields;
mod moire;
mod output;
mod pml;
mod simulation;
mod sources;
mod toml_config;
mod yee_grid;
mod verification_tests;

// Re-export public API
pub use boundaries::{BoundaryCondition, BoundaryConfig, BoundarySide};
pub use config::{ConfigPreset, FdtdConfig};
pub use fields::{FieldComponent, RealField2D, YeeFields2D};
pub use moire::{compute_moire_length, MoireConfig, MoireLattice, Monolayer, MonolayerAtom, MonolayerConfig, PermittivityCombination};
pub use output::{FieldSnapshot, SnapshotFormat, SnapshotSequence};
pub use pml::{CpmlCoefficients, PmlParams, PmlRegion};
pub use simulation::FdtdSimulation;
pub use sources::{ContinuousWaveSource, GaussianSource, Source, SourceComponent, SourceGeometry, SourceType};
pub use toml_config::{ConfigError, FdtdTomlConfig, MoireParams, MonolayerParams, OutputParams, SourceParams};
pub use yee_grid::{FieldLayout, FieldPosition, YeeGrid2D};
