//! TOML configuration parser for FDTD simulations.
//!
//! This module provides TOML-based configuration for FDTD simulations,
//! including support for moiré lattice geometries.
//!
//! # Example TOML
//!
//! ```toml
//! [fdtd]
//! polarization = "TE"
//! resolution = 32
//! courant_factor = 0.5
//! n_steps = 1000
//!
//! [fdtd.boundaries]
//! type = "pml"  # or "periodic", "mixed"
//! pml_thickness = 10
//!
//! # Standard geometry
//! [geometry]
//! lattice_type = "square"
//! a = 1.0
//! eps_bg = 12.0
//!
//! [[geometry.atoms]]
//! pos = [0.0, 0.0]
//! radius = 0.3
//! eps_inside = 1.0
//!
//! # OR Moiré geometry
//! [moire]
//! twist_angle_deg = 1.1
//! combination = "max"
//!
//! [moire.layer1]
//! lattice_type = "square"
//! a = 1.0
//! eps_bg = 6.2
//!
//! [[moire.layer1.atoms]]
//! pos = [0.0, 0.0]
//! r_over_a = 0.22
//! eps_inside = 1.0
//!
//! # Sources
//! [[sources]]
//! type = "gaussian"
//! frequency = 0.4
//! fwidth = 0.2
//! position = [0.5, 0.5]
//! component = "Hz"
//!
//! # Output
//! [output]
//! snapshot_interval = 100
//! format = "csv"
//! path = "./output"
//! ```

use std::fs;
use std::path::Path;

use serde::{Deserialize, Serialize};

use crate::geometry::{BasisAtom, Geometry2D};
use crate::grid::Grid2D;
use crate::lattice::Lattice2D;
use crate::polarization::Polarization;

use super::boundaries::{BoundaryConfig, BoundarySide};
use super::config::FdtdConfig;
use super::fields::FieldComponent;
use super::moire::{MoireConfig, MoireLattice, MonolayerAtom, MonolayerConfig};
use super::output::SnapshotFormat;
use super::pml::PmlParams;
use super::sources::{GaussianSource, Source, SourceComponent, SourceGeometry, SourceType};

/// Complete FDTD simulation configuration from TOML.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FdtdTomlConfig {
    /// FDTD solver parameters
    #[serde(default)]
    pub fdtd: FdtdParams,

    /// Standard geometry (mutually exclusive with moire)
    pub geometry: Option<GeometryParams>,

    /// Moiré geometry (mutually exclusive with geometry)
    pub moire: Option<MoireParams>,

    /// Sources for excitation
    #[serde(default)]
    pub sources: Vec<SourceParams>,

    /// Output configuration
    #[serde(default)]
    pub output: OutputParams,
}

impl FdtdTomlConfig {
    /// Load configuration from a TOML file.
    pub fn from_file(path: &Path) -> Result<Self, ConfigError> {
        let content = fs::read_to_string(path)
            .map_err(|e| ConfigError::IoError(e.to_string()))?;
        Self::from_str(&content)
    }

    /// Parse configuration from a TOML string.
    pub fn from_str(toml_str: &str) -> Result<Self, ConfigError> {
        toml::from_str(toml_str)
            .map_err(|e| ConfigError::ParseError(e.to_string()))
    }

    /// Validate the configuration.
    pub fn validate(&self) -> Result<(), ConfigError> {
        // Must have either geometry or moire, not both
        match (&self.geometry, &self.moire) {
            (None, None) => {
                return Err(ConfigError::ValidationError(
                    "Must specify either [geometry] or [moire] section".to_string(),
                ));
            }
            (Some(_), Some(_)) => {
                return Err(ConfigError::ValidationError(
                    "Cannot specify both [geometry] and [moire] sections".to_string(),
                ));
            }
            _ => {}
        }

        // Validate FDTD params
        if self.fdtd.resolution <= 0.0 {
            return Err(ConfigError::ValidationError(
                "resolution must be positive".to_string(),
            ));
        }
        if self.fdtd.courant_factor <= 0.0 || self.fdtd.courant_factor > 1.0 {
            return Err(ConfigError::ValidationError(
                "courant_factor must be in (0, 1]".to_string(),
            ));
        }

        Ok(())
    }

    /// Check if this is a moiré simulation.
    pub fn is_moire(&self) -> bool {
        self.moire.is_some()
    }

    /// Build an FdtdConfig from the TOML parameters.
    pub fn build_fdtd_config(&self) -> FdtdConfig {
        let mut config = FdtdConfig::new()
            .polarization(self.fdtd.polarization)
            .resolution(self.fdtd.resolution)
            .courant_factor(self.fdtd.courant_factor)
            .pml_thickness(self.fdtd.boundaries.pml_thickness);

        if let Some(n) = self.fdtd.n_steps {
            config = config.n_steps(n);
        }
        if let Some(t) = self.fdtd.run_time {
            config = config.run_time(t);
        }

        // Set boundaries
        config = match self.fdtd.boundaries.boundary_type.as_str() {
            "periodic" => config.all_periodic(),
            "pml" => config.all_pml(),
            "mixed" => {
                // Periodic in x, PML in y
                let mut bc = BoundaryConfig::periodic_x_pml_y();
                if let Some(thickness) = Some(self.fdtd.boundaries.pml_thickness) {
                    let params = PmlParams::with_thickness(thickness);
                    bc.y_lo = BoundarySide::pml_with(params.clone());
                    bc.y_hi = BoundarySide::pml_with(params);
                }
                config.boundaries(bc)
            }
            _ => config.all_pml(),
        };

        // Set domain size
        if let Some(ref geom) = self.geometry {
            config = config.domain_size(geom.domain_size[0], geom.domain_size[1]);
        } else if let Some(ref moire) = self.moire {
            config = config.domain_size(moire.cells_x as f64, moire.cells_y as f64);
        }

        config
    }

    /// Build a Geometry2D from standard geometry parameters.
    pub fn build_geometry(&self) -> Option<Geometry2D> {
        self.geometry.as_ref().map(|g| g.to_geometry())
    }

    /// Build a MoireLattice from moiré parameters.
    pub fn build_moire(&self) -> Option<MoireLattice> {
        self.moire.as_ref().map(|m| m.to_moire_lattice())
    }

    /// Build sources from the configuration.
    pub fn build_sources(&self) -> Vec<Source> {
        self.sources.iter().map(|s| s.to_source()).collect()
    }

    /// Get the grid for the simulation domain.
    pub fn build_grid(&self) -> Grid2D {
        let resolution = self.fdtd.resolution;

        if let Some(ref geom) = self.geometry {
            let lx = geom.a * geom.domain_size[0];
            let ly = geom.a * geom.domain_size[1];
            let nx = (lx * resolution).round() as usize;
            let ny = (ly * resolution).round() as usize;
            Grid2D::new(nx, ny, lx, ly)
        } else if let Some(ref moire) = self.moire {
            let moire_lattice = moire.to_moire_lattice();
            let lx = moire_lattice.moire_length() * moire.cells_x as f64;
            let ly = moire_lattice.moire_length() * moire.cells_y as f64;
            let nx = (lx * resolution).round() as usize;
            let ny = (ly * resolution).round() as usize;
            Grid2D::new(nx, ny, lx, ly)
        } else {
            // Default 1x1 domain
            let nx = resolution as usize;
            Grid2D::new(nx, nx, 1.0, 1.0)
        }
    }
}

/// FDTD solver parameters.
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(default)]
pub struct FdtdParams {
    pub polarization: Polarization,
    pub resolution: f64,
    pub courant_factor: f64,
    pub n_steps: Option<usize>,
    pub run_time: Option<f64>,
    pub boundaries: BoundaryParams,
}

impl Default for FdtdParams {
    fn default() -> Self {
        Self {
            polarization: Polarization::TE,
            resolution: 32.0,
            courant_factor: 0.5,
            n_steps: Some(1000),
            run_time: None,
            boundaries: BoundaryParams::default(),
        }
    }
}

/// Boundary configuration parameters.
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(default)]
pub struct BoundaryParams {
    #[serde(rename = "type")]
    pub boundary_type: String,
    pub pml_thickness: usize,
}

impl Default for BoundaryParams {
    fn default() -> Self {
        Self {
            boundary_type: "pml".to_string(),
            pml_thickness: 10,
        }
    }
}

/// Standard geometry parameters.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GeometryParams {
    pub lattice_type: String,
    #[serde(default = "default_a")]
    pub a: f64,
    pub b: Option<f64>,
    #[serde(default = "default_eps_bg")]
    pub eps_bg: f64,
    #[serde(default)]
    pub atoms: Vec<AtomParams>,
    #[serde(default = "default_domain_size")]
    pub domain_size: [f64; 2],
}

fn default_a() -> f64 {
    1.0
}

fn default_eps_bg() -> f64 {
    12.0
}

fn default_domain_size() -> [f64; 2] {
    [1.0, 1.0]
}

impl GeometryParams {
    pub fn to_geometry(&self) -> Geometry2D {
        let lattice = match self.lattice_type.to_lowercase().as_str() {
            "square" => Lattice2D::square(self.a),
            "triangular" | "hexagonal" => Lattice2D::hexagonal(self.a),
            "rectangular" => {
                let b = self.b.unwrap_or(self.a * 1.5);
                Lattice2D::rectangular(self.a, b)
            }
            _ => Lattice2D::square(self.a),
        };

        let atoms: Vec<BasisAtom> = self
            .atoms
            .iter()
            .map(|a| BasisAtom {
                pos: a.pos,
                radius: a.radius,
                eps_inside: a.eps_inside,
            })
            .collect();

        Geometry2D {
            lattice,
            eps_bg: self.eps_bg,
            atoms,
        }
    }
}

/// Atom parameters for standard geometry.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AtomParams {
    #[serde(default)]
    pub pos: [f64; 2],
    pub radius: f64,
    #[serde(default = "default_eps_inside")]
    pub eps_inside: f64,
}

fn default_eps_inside() -> f64 {
    1.0
}

/// Moiré geometry parameters.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MoireParams {
    pub twist_angle_deg: f64,
    #[serde(default)]
    pub combination: super::moire::PermittivityCombination,
    pub layer1: MonolayerParams,
    pub layer2: Option<MonolayerParams>,
    #[serde(default = "default_cells")]
    pub cells_x: usize,
    #[serde(default = "default_cells")]
    pub cells_y: usize,
}

fn default_cells() -> usize {
    1
}

impl MoireParams {
    pub fn to_moire_lattice(&self) -> MoireLattice {
        let config = MoireConfig {
            layer1: self.layer1.to_monolayer_config(),
            layer2: self.layer2.as_ref().map(|l| l.to_monolayer_config()),
            twist_angle_deg: self.twist_angle_deg,
            combination: self.combination,
            cells_x: self.cells_x,
            cells_y: self.cells_y,
        };
        MoireLattice::from_config(&config)
    }

    /// Get the computed moiré length.
    pub fn moire_length(&self) -> f64 {
        super::moire::compute_moire_length(
            self.layer1.a,
            self.twist_angle_deg.to_radians(),
        )
    }
}

/// Monolayer parameters for moiré.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MonolayerParams {
    pub lattice_type: String,
    #[serde(default = "default_a")]
    pub a: f64,
    pub b: Option<f64>,
    #[serde(default)]
    pub rotation_deg: f64,
    #[serde(default = "default_eps_bg")]
    pub eps_bg: f64,
    #[serde(default)]
    pub atoms: Vec<MonolayerAtomParams>,
}

impl MonolayerParams {
    pub fn to_monolayer_config(&self) -> MonolayerConfig {
        MonolayerConfig {
            lattice_type: self.lattice_type.clone(),
            a: self.a,
            b: self.b,
            rotation_deg: self.rotation_deg,
            eps_bg: self.eps_bg,
            atoms: self.atoms.iter().map(|a| a.to_atom()).collect(),
        }
    }
}

/// Atom parameters for monolayer.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MonolayerAtomParams {
    #[serde(default)]
    pub pos: [f64; 2],
    pub r_over_a: f64,
    #[serde(default = "default_eps_inside")]
    pub eps_inside: f64,
}

impl MonolayerAtomParams {
    pub fn to_atom(&self) -> MonolayerAtom {
        MonolayerAtom {
            pos: self.pos,
            r_over_a: self.r_over_a,
            eps_inside: self.eps_inside,
        }
    }
}

/// Source parameters.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SourceParams {
    #[serde(rename = "type")]
    pub source_type: String,
    pub frequency: f64,
    #[serde(default = "default_fwidth")]
    pub fwidth: f64,
    pub position: [f64; 2],
    #[serde(default = "default_component")]
    pub component: String,
    #[serde(default = "default_amplitude")]
    pub amplitude: f64,
}

fn default_fwidth() -> f64 {
    0.2
}

fn default_component() -> String {
    "Hz".to_string()
}

fn default_amplitude() -> f64 {
    1.0
}

impl SourceParams {
    pub fn to_source(&self) -> Source {
        let geometry = SourceGeometry::point(self.position[0], self.position[1]);

        let component = match self.component.to_uppercase().as_str() {
            "EZ" => SourceComponent::Electric(FieldComponent::Ez),
            "EX" => SourceComponent::Electric(FieldComponent::Ex),
            "EY" => SourceComponent::Electric(FieldComponent::Ey),
            "HZ" => SourceComponent::Magnetic(FieldComponent::Hz),
            "HX" => SourceComponent::Magnetic(FieldComponent::Hx),
            "HY" => SourceComponent::Magnetic(FieldComponent::Hy),
            _ => SourceComponent::Magnetic(FieldComponent::Hz), // Default TE
        };

        let source_type = match self.source_type.to_lowercase().as_str() {
            "gaussian" => {
                let mut gs = GaussianSource::from_bandwidth(self.frequency, self.fwidth);
                gs.amplitude = self.amplitude;
                SourceType::Gaussian(gs)
            }
            _ => {
                let gs = GaussianSource::from_bandwidth(self.frequency, self.fwidth);
                SourceType::Gaussian(gs)
            }
        };

        Source::new(source_type, geometry, component)
    }
}

/// Output configuration.
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(default)]
pub struct OutputParams {
    pub snapshot_interval: usize,
    pub format: String,
    pub path: String,
    pub save_permittivity: bool,
}

impl Default for OutputParams {
    fn default() -> Self {
        Self {
            snapshot_interval: 100,
            format: "csv".to_string(),
            path: "./output".to_string(),
            save_permittivity: true,
        }
    }
}

impl OutputParams {
    pub fn snapshot_format(&self) -> SnapshotFormat {
        match self.format.to_lowercase().as_str() {
            "csv" => SnapshotFormat::Csv,
            "binary" | "bin" => SnapshotFormat::Binary,
            "numpy" | "npy" => SnapshotFormat::Numpy,
            _ => SnapshotFormat::Csv,
        }
    }
}

/// Configuration error types.
#[derive(Debug, Clone)]
pub enum ConfigError {
    IoError(String),
    ParseError(String),
    ValidationError(String),
}

impl std::fmt::Display for ConfigError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            ConfigError::IoError(s) => write!(f, "IO error: {}", s),
            ConfigError::ParseError(s) => write!(f, "Parse error: {}", s),
            ConfigError::ValidationError(s) => write!(f, "Validation error: {}", s),
        }
    }
}

impl std::error::Error for ConfigError {}

// ============================================================================
// Tests
// ============================================================================

#[cfg(test)]
mod tests {
    use super::*;

    const SIMPLE_TOML: &str = r#"
[fdtd]
polarization = "TE"
resolution = 32
n_steps = 100

[geometry]
lattice_type = "square"
a = 1.0
eps_bg = 12.0

[[geometry.atoms]]
pos = [0.0, 0.0]
radius = 0.3
eps_inside = 1.0

[[sources]]
type = "gaussian"
frequency = 0.4
fwidth = 0.2
position = [0.5, 0.5]
component = "Hz"
"#;

    const MOIRE_TOML: &str = r#"
[fdtd]
polarization = "TE"
resolution = 16
n_steps = 100

[fdtd.boundaries]
type = "pml"
pml_thickness = 10

[moire]
twist_angle_deg = 1.1
combination = "max"
cells_x = 1
cells_y = 1

[moire.layer1]
lattice_type = "square"
a = 1.0
eps_bg = 6.2

[[moire.layer1.atoms]]
pos = [0.0, 0.0]
r_over_a = 0.22
eps_inside = 1.0

[[sources]]
type = "gaussian"
frequency = 0.4
fwidth = 0.2
position = [26.0, 26.0]
component = "Hz"

[output]
snapshot_interval = 50
format = "csv"
path = "./moire_output"
"#;

    #[test]
    fn test_parse_simple_geometry() {
        let config = FdtdTomlConfig::from_str(SIMPLE_TOML).unwrap();
        assert!(config.validate().is_ok());
        assert!(!config.is_moire());
        assert!(config.geometry.is_some());
    }

    #[test]
    fn test_parse_moire_geometry() {
        let config = FdtdTomlConfig::from_str(MOIRE_TOML).unwrap();
        assert!(config.validate().is_ok());
        assert!(config.is_moire());

        let moire = config.build_moire().unwrap();
        let l_m = moire.moire_length();
        assert!((l_m - 52.1).abs() < 0.5, "L_m = {}", l_m);
    }

    #[test]
    fn test_build_fdtd_config() {
        let config = FdtdTomlConfig::from_str(SIMPLE_TOML).unwrap();
        let fdtd_config = config.build_fdtd_config();

        assert_eq!(fdtd_config.polarization, Polarization::TE);
        assert_eq!(fdtd_config.resolution, 32.0);
    }

    #[test]
    fn test_build_sources() {
        let config = FdtdTomlConfig::from_str(SIMPLE_TOML).unwrap();
        let sources = config.build_sources();

        assert_eq!(sources.len(), 1);
    }

    #[test]
    fn test_moire_length_from_params() {
        let config = FdtdTomlConfig::from_str(MOIRE_TOML).unwrap();
        let moire_params = config.moire.as_ref().unwrap();
        let l_m = moire_params.moire_length();

        assert!((l_m - 52.1).abs() < 0.5, "L_m = {}", l_m);
    }
}
