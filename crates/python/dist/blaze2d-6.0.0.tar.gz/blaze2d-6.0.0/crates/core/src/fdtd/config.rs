//! Configuration for FDTD simulations.
//!
//! This module provides the configuration structures for setting up FDTD
//! simulations, including grid resolution, time stepping, boundaries, and
//! physical parameters.

use serde::{Deserialize, Serialize};

use crate::polarization::Polarization;

use super::boundaries::BoundaryConfig;

/// Main configuration for FDTD simulation.
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(default)]
pub struct FdtdConfig {
    /// Polarization mode (TE or TM). TE is default.
    pub polarization: Polarization,

    /// Grid resolution (points per unit length).
    /// If resolution_y is not specified, uses this for both directions.
    pub resolution: f64,

    /// Optional separate resolution in y direction.
    pub resolution_y: Option<f64>,

    /// Domain size in units of lattice constant [Lx, Ly].
    /// Default is [1.0, 1.0] for a single unit cell.
    pub domain_size: [f64; 2],

    /// Courant factor for time step calculation (0 < S ≤ 1).
    /// dt = S / (c * sqrt(1/dx² + 1/dy²))
    /// Default is 0.5 for stability margin.
    pub courant_factor: f64,

    /// PML thickness in grid cells.
    pub pml_thickness: usize,

    /// Boundary configuration.
    pub boundaries: BoundaryConfig,

    /// Total simulation time (in normalized units c*t/a).
    pub run_time: Option<f64>,

    /// Number of time steps to run (alternative to run_time).
    pub n_steps: Option<usize>,

    /// Whether to use parallel execution (Rayon) for field updates.
    /// If false (default), runs on a single thread.
    #[serde(default)]
    pub use_parallel: bool,

    /// Verbosity level (0 = silent, 1 = basic, 2 = detailed).
    pub verbosity: u8,
}

impl Default for FdtdConfig {
    fn default() -> Self {
        Self {
            polarization: Polarization::TE, // TE is default as requested
            resolution: 32.0,
            resolution_y: None,
            domain_size: [1.0, 1.0],
            courant_factor: 0.5,
            pml_thickness: 10,
            boundaries: BoundaryConfig::default(),
            run_time: None,
            n_steps: Some(1000),
            verbosity: 1,
            use_parallel: false,
        }
    }
}

impl FdtdConfig {
    /// Create a new config with default values.
    pub fn new() -> Self {
        Self::default()
    }

    /// Set polarization mode.
    pub fn polarization(mut self, pol: Polarization) -> Self {
        self.polarization = pol;
        self
    }

    /// Set TE mode.
    pub fn te(mut self) -> Self {
        self.polarization = Polarization::TE;
        self
    }

    /// Set TM mode.
    pub fn tm(mut self) -> Self {
        self.polarization = Polarization::TM;
        self
    }

    /// Set resolution (uniform in both directions).
    pub fn resolution(mut self, res: f64) -> Self {
        self.resolution = res;
        self.resolution_y = None;
        self
    }

    /// Set separate resolutions for x and y.
    pub fn resolution_xy(mut self, res_x: f64, res_y: f64) -> Self {
        self.resolution = res_x;
        self.resolution_y = Some(res_y);
        self
    }

    /// Set domain size.
    pub fn domain_size(mut self, lx: f64, ly: f64) -> Self {
        self.domain_size = [lx, ly];
        self
    }

    /// Set Courant factor.
    pub fn courant_factor(mut self, s: f64) -> Self {
        assert!(s > 0.0 && s <= 1.0, "Courant factor must be in (0, 1]");
        self.courant_factor = s;
        self
    }

    /// Set PML thickness.
    pub fn pml_thickness(mut self, thickness: usize) -> Self {
        self.pml_thickness = thickness;
        self
    }

    /// Set boundary configuration.
    pub fn boundaries(mut self, boundaries: BoundaryConfig) -> Self {
        self.boundaries = boundaries;
        self
    }

    /// Set all boundaries to PML.
    pub fn all_pml(mut self) -> Self {
        self.boundaries = BoundaryConfig::all_pml();
        self
    }

    /// Set all boundaries to periodic.
    pub fn all_periodic(mut self) -> Self {
        self.boundaries = BoundaryConfig::all_periodic();
        self
    }

    /// Set run time.
    pub fn run_time(mut self, time: f64) -> Self {
        self.run_time = Some(time);
        self.n_steps = None;
        self
    }

    /// Set number of steps.
    pub fn n_steps(mut self, n: usize) -> Self {
        self.n_steps = Some(n);
        self.run_time = None;
        self
    }

    /// Set verbosity level.
    pub fn verbosity(mut self, v: u8) -> Self {
        self.verbosity = v;
        self
    }

    /// Get x resolution.
    pub fn resolution_x(&self) -> usize {
        (self.resolution * self.domain_size[0]).round() as usize
    }

    /// Get y resolution (may differ from x).
    pub fn resolution_y(&self) -> usize {
        let res = self.resolution_y.unwrap_or(self.resolution);
        (res * self.domain_size[1]).round() as usize
    }

    /// Validate configuration.
    pub fn validate(&self) -> Result<(), String> {
        if self.resolution <= 0.0 {
            return Err("Resolution must be positive".to_string());
        }
        if self.courant_factor <= 0.0 || self.courant_factor > 1.0 {
            return Err("Courant factor must be in (0, 1]".to_string());
        }
        if self.domain_size[0] <= 0.0 || self.domain_size[1] <= 0.0 {
            return Err("Domain size must be positive".to_string());
        }
        self.boundaries.validate()?;
        Ok(())
    }
}

/// Configuration preset for common simulation types.
#[derive(Debug, Clone, Copy)]
pub enum ConfigPreset {
    /// Quick low-resolution test
    Test,
    /// Standard simulation
    Standard,
    /// High-resolution production run
    Production,
    /// Minimal for debugging
    Debug,
}

impl ConfigPreset {
    /// Create an FdtdConfig from a preset.
    pub fn to_config(self) -> FdtdConfig {
        match self {
            Self::Test => FdtdConfig::new()
                .resolution(16.0)
                .n_steps(100)
                .pml_thickness(5),
            Self::Standard => FdtdConfig::new()
                .resolution(32.0)
                .n_steps(1000)
                .pml_thickness(10),
            Self::Production => FdtdConfig::new()
                .resolution(64.0)
                .n_steps(5000)
                .pml_thickness(20),
            Self::Debug => FdtdConfig::new()
                .resolution(8.0)
                .n_steps(10)
                .pml_thickness(2)
                .verbosity(2),
        }
    }
}

impl From<ConfigPreset> for FdtdConfig {
    fn from(preset: ConfigPreset) -> Self {
        preset.to_config()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_default_config() {
        let config = FdtdConfig::default();
        assert_eq!(config.polarization, Polarization::TE);
        assert!(config.validate().is_ok());
    }

    #[test]
    fn test_builder_pattern() {
        let config = FdtdConfig::new()
            .tm()
            .resolution(48.0)
            .domain_size(2.0, 2.0)
            .courant_factor(0.4)
            .n_steps(500);

        assert_eq!(config.polarization, Polarization::TM);
        assert_eq!(config.resolution, 48.0);
        assert_eq!(config.resolution_x(), 96);
        assert_eq!(config.resolution_y(), 96);
        assert!(config.validate().is_ok());
    }

    #[test]
    fn test_preset_configs() {
        let test_config: FdtdConfig = ConfigPreset::Test.into();
        assert_eq!(test_config.resolution, 16.0);

        let prod_config: FdtdConfig = ConfigPreset::Production.into();
        assert!(prod_config.resolution > test_config.resolution);
    }

    #[test]
    fn test_validation_invalid_resolution() {
        let config = FdtdConfig {
            resolution: -1.0,
            ..Default::default()
        };
        assert!(config.validate().is_err());
    }

    #[test]
    fn test_validation_invalid_courant() {
        let config = FdtdConfig {
            courant_factor: 1.5,
            ..Default::default()
        };
        assert!(config.validate().is_err());
    }
}
