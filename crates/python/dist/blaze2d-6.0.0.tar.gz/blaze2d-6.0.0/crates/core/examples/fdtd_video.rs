//! FDTD runner that saves frames for video output.
//!
//! This saves Hz field snapshots at regular intervals for later video creation.
//! Run with: cargo run --release -p blaze2d-core --example fdtd_video -- testing_fdtd/config.toml

use std::env;
use std::fs::{self, File};
use std::io::{BufWriter, Write};
use std::path::Path;

use blaze2d_core::fdtd::{FdtdTomlConfig, YeeGrid2D};
use blaze2d_core::grid::Grid2D;

fn main() {
    // Get config path from args
    let args: Vec<String> = env::args().collect();
    let config_path = if args.len() > 1 {
        &args[1]
    } else {
        "testing_fdtd/config.toml"
    };

    println!("============================================================");
    println!("Blaze2D FDTD Video Frame Generator");
    println!("============================================================");
    println!("Loading config from: {}", config_path);

    // Load and parse TOML config
    let toml_content = fs::read_to_string(config_path).expect("Failed to read config file");
    let config: FdtdTomlConfig = toml::from_str(&toml_content).expect("Failed to parse TOML config");

    // Validate
    config.validate().expect("Invalid configuration");

    // Extract parameters
    let resolution = config.fdtd.resolution;
    let pml_thickness = if config.fdtd.boundaries.pml_thickness < 5 {
        ((config.fdtd.boundaries.pml_thickness as f64) * resolution).round() as usize
    } else {
        config.fdtd.boundaries.pml_thickness
    };
    
    // Ensure sufficient PML thickness (at least 10 cells often needed)
    println!("PML thickness: {} cells", pml_thickness);
    let run_time = config.fdtd.run_time.unwrap_or(50.0);  // Longer for video
    let courant = config.fdtd.courant_factor;

    // Video parameters
    let dt_output = 0.5;  // Time between frames (must match Meep)

    // Build moiré lattice
    let moire_params = config.moire.as_ref().expect("Expected moiré config");
    let moire = moire_params.to_moire_lattice();

    let twist_angle = moire_params.twist_angle_deg;
    let a = moire_params.layer1.a;
    let r_over_a = moire_params.layer1.atoms.first().map(|atom| atom.r_over_a).unwrap_or(0.22);
    let eps_bg = moire_params.layer1.eps_bg;

    // Domain: 5x5 unit cells + PML
    let n_cells = 5;
    let domain_size = n_cells as f64 * a;
    let total_size = domain_size + 2.0 * (pml_thickness as f64 / resolution);

    println!("Lattice constant a = {}", a);
    println!("Hole radius r/a = {}", r_over_a);
    println!("Background eps = {}", eps_bg);
    println!("Twist angle = {}°", twist_angle);
    println!("Total size: {}x{}", total_size, total_size);
    println!("Resolution = {}", resolution);
    println!("Run time = {}", run_time);
    println!("Frame interval = {}", dt_output);
    println!("============================================================");

    // Create Yee grid
    let grid = YeeGrid2D::new(total_size, total_size, resolution);
    let dx = grid.dx();
    let dt = courant * grid.courant_dt(courant);
    let nx = grid.nx();
    let ny = grid.ny();

    println!("Grid size: {} x {}", nx, ny);

    // Calculate number of time steps
    let n_steps = (run_time / dt).ceil() as usize;
    let steps_per_frame = (dt_output / dt).round() as usize;
    let n_frames = n_steps / steps_per_frame + 1;

    println!("Time step dt = {:.6e}", dt);
    println!("Number of steps = {}", n_steps);
    println!("Steps per frame = {}", steps_per_frame);
    println!("Expected frames = {}", n_frames);

    // Sample permittivity
    println!("\nSampling permittivity...");
    let sample_grid = Grid2D::new_centered(nx, ny, total_size, total_size);
    let eps_grid = moire.sample_permittivity_tiled_analytic(&sample_grid, resolution as usize);

    // Initialize fields (TE: Hz, Ex, Ey)
    println!("Initializing fields...");
    let mut hz = vec![0.0f64; nx * ny];
    let mut ex = vec![0.0f64; nx * ny];
    let mut ey = vec![0.0f64; nx * ny];

    // PML auxiliary fields
    let mut psi_hzx = vec![0.0f64; nx * ny];
    let mut psi_hzy = vec![0.0f64; nx * ny];
    let mut psi_eyx = vec![0.0f64; nx * ny];
    let mut psi_exy = vec![0.0f64; nx * ny];

    // PML parameters
    // Optimal sigma: 0.8 * (m + 1) / (dx * \sqrt{eps_bg}) usually, or similar.
    // Blaze2D library uses 0.8 * (m + 1) / dx.
    // For polynomial order m=3:
    let pml_sigma_max = 0.8 * (3.0 + 1.0) / dx;
    let pml_phys = pml_thickness as f64 * dx;

    let compute_sigma = |d: f64| -> f64 {
        if d <= 0.0 { 0.0 } else { pml_sigma_max * (d / pml_phys).powi(3) }
    };
    
    // Helper to find checking distance into PML from either side
    let pml_dist = |u: f64, L: f64| -> f64 {
        let lo = (pml_phys - u).max(0.0);
        let hi = (u - (L - pml_phys)).max(0.0);
        lo.max(hi)
    };

    // Precompute coefficients
    let mut bx_ey = vec![0.0f64; nx];
    let mut cx_ey = vec![0.0f64; nx];
    let mut bx_hz = vec![0.0f64; nx]; 
    let mut cx_hz = vec![0.0f64; nx];
    
    for ix in 0..nx {
        let x_int = ix as f64 * dx;
        let s_int = compute_sigma(pml_dist(x_int, total_size));
        bx_ey[ix] = (-s_int * dt).exp();
        cx_ey[ix] = if s_int > 1e-10 { bx_ey[ix] - 1.0 } else { 0.0 };
        
        let x_half = (ix as f64 + 0.5) * dx;
        let s_half = compute_sigma(pml_dist(x_half, total_size));
        bx_hz[ix] = (-s_half * dt).exp();
        cx_hz[ix] = if s_half > 1e-10 { bx_hz[ix] - 1.0 } else { 0.0 };
    }
    
    let mut by_ex = vec![0.0f64; ny];
    let mut cy_ex = vec![0.0f64; ny];
    let mut by_hz = vec![0.0f64; ny];
    let mut cy_hz = vec![0.0f64; ny];
    
    for iy in 0..ny {
        let y_int = iy as f64 * dx;
        let s_int = compute_sigma(pml_dist(y_int, total_size));
        by_ex[iy] = (-s_int * dt).exp();
        cy_ex[iy] = if s_int > 1e-10 { by_ex[iy] - 1.0 } else { 0.0 };
        
        let y_half = (iy as f64 + 0.5) * dx;
        let s_half = compute_sigma(pml_dist(y_half, total_size));
        by_hz[iy] = (-s_half * dt).exp();
        cy_hz[iy] = if s_half > 1e-10 { by_hz[iy] - 1.0 } else { 0.0 };
    }

    // Source parameters
    let source_params = config.sources.first().expect("Need at least one source");
    let fcen = source_params.frequency;
    let fwidth = source_params.fwidth;
    let source_x = source_params.position[0];
    let source_y = source_params.position[1];

    // Convert source position to grid indices
    // Grid is centered: position (0,0) should map to center of grid (nx/2, ny/2)
    let src_ix = ((source_x + total_size / 2.0) / dx).round() as usize;
    let src_iy = ((source_y + total_size / 2.0) / dx).round() as usize;
    let src_ix = src_ix.min(nx - 1);
    let src_iy = src_iy.min(ny - 1);

    // Gaussian source timing
    let omega0 = 2.0 * std::f64::consts::PI * fcen;
    // Meep defines fwidth such that the time width is w = 1/fwidth
    let sigma_t = 1.0 / fwidth; 
    // Shift t0 back by 0.5s to align frames (Meep was 1 frame ahead originally)
    let t0 = 5.0 * sigma_t - 0.5; 

    println!("Source at grid position ({}, {})", src_ix, src_iy);
    println!("Gaussian pulse: f_cen = {}, fwidth = {}", fcen, fwidth);

    // Create output directory for frames
    let frames_dir = Path::new("testing_fdtd/rust_frames");
    fs::create_dir_all(frames_dir).expect("Failed to create frames directory");

    // Clear old frames
    for entry in fs::read_dir(frames_dir).unwrap() {
        let entry = entry.unwrap();
        if entry.path().extension().map_or(false, |e| e == "csv") {
            fs::remove_file(entry.path()).ok();
        }
    }

    // Storage for frame times and field ranges
    let mut frame_times: Vec<f64> = Vec::new();
    let mut hz_min_global = f64::INFINITY;
    let mut hz_max_global = f64::NEG_INFINITY;

    // Buffer for fast IO
    let mut scratch_buffer: Vec<u8> = Vec::with_capacity(nx * ny * 15);

    // Optimization constants
    let inv_dx = 1.0 / dx;
    let inv_dx_sq = inv_dx * inv_dx;

    // Time stepping with frame output
    println!("\nRunning simulation for {} steps...", n_steps);
    let mut frame_count = 0;

    for step in 0..=n_steps {
        let t = step as f64 * dt;

        // Save frame at regular intervals
        if step % steps_per_frame == 0 {
            // Track field range
            let hz_min = hz.iter().cloned().fold(f64::INFINITY, f64::min);
            let hz_max = hz.iter().cloned().fold(f64::NEG_INFINITY, f64::max);
            hz_min_global = hz_min_global.min(hz_min);
            hz_max_global = hz_max_global.max(hz_max);

            // Save frame (Optimized IO)
            scratch_buffer.clear();
            for iy in 0..ny {
                for ix in 0..nx {
                    write!(&mut scratch_buffer, "{:.6e}", hz[iy * nx + ix]).unwrap();
                    if ix < nx - 1 {
                        scratch_buffer.push(b',');
                    }
                }
                scratch_buffer.push(b'\n');
            }

            let frame_path = frames_dir.join(format!("frame_{:06}.csv", frame_count));
            let mut frame_file = File::create(&frame_path).expect("Failed to create frame file");
            frame_file.write_all(&scratch_buffer).expect("Failed to write frame");

            frame_times.push(t);
            println!("  Frame {}: t = {:.3}", frame_count, t);
            frame_count += 1;
        }

        if step >= n_steps {
            break;
        }

        // 1. Update Hz (from Ex, Ey)
        // Optimized with slice iteration to maximize SIMD auto-vectorization
        let bx_slice = &bx_hz[0..(nx-1)];
        let cx_slice = &cx_hz[0..(nx-1)];

        for iy in 0..ny - 1 {
            let offset = iy * nx;
            let len = nx - 1;
            let by = by_hz[iy];
            let cy = cy_hz[iy];

            let hz_row = &mut hz[offset..offset+len];
            let psi_hzy_row = &mut psi_hzy[offset..offset+len];
            let psi_hzx_row = &mut psi_hzx[offset..offset+len];

            // ey_row needs [i] and [i+1]
            let ey_row = &ey[offset..offset+len+1];
            
            // ex needs row iy and iy+1
            let ex_curr = &ex[offset..offset+len];
            let ex_next = &ex[(iy + 1)*nx..(iy + 1)*nx+len];

            for i in 0..len {
                let dey_dx = (ey_row[i+1] - ey_row[i]) * inv_dx;
                let dex_dy = (ex_next[i] - ex_curr[i]) * inv_dx; // dEx/dy
                
                let bx = bx_slice[i];
                let cx = cx_slice[i];
                
                let p_hzy = psi_hzy_row[i];
                let new_psi_hzy = by * p_hzy + cy * dex_dy;
                psi_hzy_row[i] = new_psi_hzy;

                let p_hzx = psi_hzx_row[i];
                let new_psi_hzx = bx * p_hzx + cx * dey_dx;
                psi_hzx_row[i] = new_psi_hzx;

                hz_row[i] += dt * ( (dex_dy + new_psi_hzy) - (dey_dx + new_psi_hzx) );
            }
        }

        // 2. Inject Hz source (soft source)
        let src_val = (-0.5 * ((t - t0) / sigma_t).powi(2)).exp()
            * (omega0 * (t - t0)).cos();
        let src_idx = src_iy * nx + src_ix;
        // Scale by 1/(dx*dx) to treat amplitude as total current I, not density J
        // Flip sign to match Meep (-1.0)
        hz[src_idx] -= src_val * dt * inv_dx_sq;

        // 3. Update Ex (from Hz)
        for iy in 1..ny {
            let offset = iy * nx;
            let prev_offset = (iy - 1) * nx;
            let len = nx;
            
            let by = by_ex[iy];
            let cy = cy_ex[iy];
            
            let ex_row = &mut ex[offset..offset+len];
            let psi_exy_row = &mut psi_exy[offset..offset+len];
            let eps_row = &eps_grid[offset..offset+len];
            
            let hz_curr = &hz[offset..offset+len];
            let hz_prev = &hz[prev_offset..prev_offset+len];

            for i in 0..len {
                let dhz_dy = (hz_curr[i] - hz_prev[i]) * inv_dx;
                let eps = eps_row[i];
                
                let p_exy = psi_exy_row[i];
                let new_psi_exy = by * p_exy + cy * dhz_dy;
                psi_exy_row[i] = new_psi_exy;
                
                ex_row[i] += (dt / eps) * (dhz_dy + new_psi_exy);
            }
        }

        // 4. Update Ey (from Hz)
        let bx_slice = &bx_ey[1..nx];
        let cx_slice = &cx_ey[1..nx];

        for iy in 0..ny {
            let offset = iy * nx;
            // Ey loop is 1..nx, so length is nx-1
            let len = nx - 1; 
            
            let ey_row = &mut ey[offset+1..offset+1+len];
            let psi_eyx_row = &mut psi_eyx[offset+1..offset+1+len];
            let eps_row = &eps_grid[offset+1..offset+1+len];
            
            // hz_row needs indices i and i+1, which map to ix-1 and ix.
            // i=0 -> ix=1. hz_row[0] is hz[0] (ix=0). hz_row[1] is hz[1]. Correct.
            let hz_row = &hz[offset..offset+len+1];

            for i in 0..len {
                let dhz_dx = (hz_row[i+1] - hz_row[i]) * inv_dx;
                let eps = eps_row[i];
                
                let bx = bx_slice[i];
                let cx = cx_slice[i];
                
                let p_eyx = psi_eyx_row[i];
                let new_psi_eyx = bx * p_eyx + cx * dhz_dx;
                psi_eyx_row[i] = new_psi_eyx;
                
                ey_row[i] -= (dt / eps) * (dhz_dx + new_psi_eyx);
            }
        }
    }

    println!("\nSimulation complete!");
    println!("Saved {} frames", frame_count);
    println!("Hz range: [{:.6e}, {:.6e}]", hz_min_global, hz_max_global);

    // Save epsilon for video overlay
    let eps_path = frames_dir.join("epsilon.csv");
    let mut eps_file = BufWriter::new(File::create(&eps_path).expect("Failed to create eps file"));
    for iy in 0..ny {
        let row: Vec<String> = (0..nx)
            .map(|ix| format!("{:.6}", eps_grid[iy * nx + ix]))
            .collect();
        writeln!(eps_file, "{}", row.join(",")).unwrap();
    }

    // Save metadata
    let metadata = serde_json::json!({
        "run_time": run_time,
        "dt_output": dt_output,
        "n_frames": frame_count,
        "fps": 20,
        "resolution": resolution,
        "total_size": total_size,
        "nx": nx,
        "ny": ny,
        "hz_min": hz_min_global,
        "hz_max": hz_max_global,
        "times": frame_times
    });

    let meta_path = frames_dir.join("metadata.json");
    let mut meta_file = File::create(&meta_path).expect("Failed to create metadata file");
    writeln!(meta_file, "{}", serde_json::to_string_pretty(&metadata).unwrap()).unwrap();

    println!("\nMetadata and frames saved to {}", frames_dir.display());
    println!("Run create_rust_video.py to generate the mp4");
}
